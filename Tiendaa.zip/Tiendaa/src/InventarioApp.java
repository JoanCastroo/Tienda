public class InventarioApp {
    public static void main(String[] args) {
        Inventario inventario = new Inventario(10);

        try {
            // Crear un objeto Producto con el constructor adecuado
            Producto producto1 = new Producto("1", "Producto 1", 5);
            try {
                inventario.agregarProducto(producto1);
            } catch (InventarioLlenoException e) {
                throw new RuntimeException(e);
            }
            // M&aacute;s operaciones de inventario
        } catch (InventarioLlenoException e) {
            System.out.println(e.getMessage());
        }
    }


    static class InventarioLlenoException extends Exception {
        public InventarioLlenoException(String mensaje ) {
            super(mensaje);
        }
    }
}