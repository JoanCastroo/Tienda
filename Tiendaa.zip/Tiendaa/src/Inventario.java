import java.util.HashMap;

public class Inventario {
    private HashMap<String, Producto> productos;
    private int capacidadMaxima;

    public Inventario(int capacidadMaxima) {
        this.productos = new HashMap<>();
        this.capacidadMaxima = capacidadMaxima;
    }

    public void agregarProducto(Producto producto) throws InventarioLlenoException {
        if (productos.size() >= capacidadMaxima) {
            throw new InventarioLlenoException("El inventario está lleno.");
        }
        productos.put(producto.getId(), producto);
    }
}