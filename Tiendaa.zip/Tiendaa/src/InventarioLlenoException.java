public class InventarioLlenoException extends Exception {
    public InventarioLlenoException(String mensaje) {
        super(mensaje);
    }
}
